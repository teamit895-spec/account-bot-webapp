'use client';

import { useState, useEffect, useCallback } from 'react';
import { WeeklyStats as WeeklyStatsType, WeeklyGroup, GroupData, cleanGroupName } from '@/types';
import { fetchWeeklyStats } from '@/lib/api';
import GroupCard from './GroupCard';

interface WeeklyStatsViewProps {
  groups: GroupData[];
  onRefreshCache: () => void;
  refreshing: boolean;
}

export default function WeeklyStatsView({ groups, onRefreshCache, refreshing }: WeeklyStatsViewProps) {
  const [weeklyData, setWeeklyData] = useState<WeeklyStatsType | null>(null);
  const [loading, setLoading] = useState(false);

  const loadWeeklyData = useCallback(async (force = false) => {
    if (loading) return;
    setLoading(true);
    try {
      const result = await fetchWeeklyStats(force);
      setWeeklyData(result);
    } catch (error) {
      console.error('Weekly stats error:', error);
    }
    setLoading(false);
  }, [loading]);

  useEffect(() => {
    loadWeeklyData();
  }, []);

  const getPercentClass = (pct: number) => {
    if (pct <= 12) return 'good';
    if (pct <= 20) return 'warning';
    return 'bad';
  };

  const medals = ['🥇', '🥈', '🥉'];
  const getMedal = (rank: number) => {
    return rank <= 3 ? medals[rank - 1] : null;
  };
  
  const getRankClass = (rank: number) => {
    if (rank === 1) return 'gold';
    if (rank === 2) return 'silver';
    if (rank === 3) return 'bronze';
    return '';
  };

  const filteredGroups = (weeklyData?.группы || [])
    .filter(гр => гр.дней_с_данными > 0 && гр.средний_процент >= 0.1)
    .sort((a, b) => a.средний_процент - b.средний_процент);

  return (
    <div className="groups-page">
      {/* Weekly Stats Table */}
      <div className="weekly-stats-container">
        <div className="weekly-stats-header">
          <div className="weekly-stats-title">
            <span>📊</span> Средний % вылетов за неделю
          </div>
          {weeklyData?.период && (
            <div className="weekly-stats-period">{weeklyData.период}</div>
          )}
        </div>

        {loading ? (
          <div className="weekly-loading">
            <div className="spinner" />
            <p style={{ marginTop: '10px' }}>Загрузка статистики...</p>
          </div>
        ) : filteredGroups.length === 0 ? (
          <div className="weekly-loading">
            <p>🔭 Нет данных за эту неделю</p>
          </div>
        ) : (
          <table className="weekly-table">
            <thead>
              <tr>
                <th style={{ width: '50px' }}>#</th>
                <th>Группа</th>
                <th style={{ width: '100px' }}>Средний %</th>
                <th style={{ width: '140px' }}>Прогресс</th>
                <th style={{ width: '80px' }}>Дней</th>
              </tr>
            </thead>
            <tbody>
              {filteredGroups.map((group, idx) => {
                const rank = idx + 1;
                const medal = getMedal(rank);
                const pctClass = getPercentClass(group.средний_процент);
                const rankClass = getRankClass(rank);
                const barWidth = Math.min(100, (group.средний_процент / 30) * 100);

                return (
                  <tr key={group.имя}>
                    <td>
                      <div className={`weekly-rank ${rankClass}`}>
                        {rank}
                      </div>
                    </td>
                    <td className="weekly-name">
                      {medal ? `${medal} ` : ''}{cleanGroupName(group.имя)}
                    </td>
                    <td>
                      <span className={`weekly-percent ${pctClass}`}>
                        {group.средний_процент}%
                      </span>
                    </td>
                    <td>
                      <div className="weekly-bar">
                        <div 
                          className={`weekly-bar-fill ${pctClass}`}
                          style={{ width: `${barWidth}%` }}
                        />
                      </div>
                    </td>
                    <td className="weekly-days">
                      {group.дней_с_данными} из {weeklyData?.текущий_день || 7}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* All Groups Section */}
      <div className="section">
        <div className="section-header">
          <h2 className="section-title">📋 Все группы</h2>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button 
              className="btn" 
              onClick={() => loadWeeklyData(true)} 
              disabled={loading}
            >
              {loading ? <span className="spinner" /> : '🔄'} Обновить рейтинг
            </button>
            <button 
              className="btn btn-primary" 
              onClick={onRefreshCache} 
              disabled={refreshing}
            >
              {refreshing ? <span className="spinner" /> : '🔄'} Обновить кеш
            </button>
          </div>
        </div>
        <div className="section-content">
          <div className="groups-grid">
            {groups.map(gr => <GroupCard key={gr.имя} group={gr} />)}
          </div>
        </div>
      </div>
    </div>
  );
}
