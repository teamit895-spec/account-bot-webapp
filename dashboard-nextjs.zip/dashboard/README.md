# Stats Dashboard - Next.js

Полный порт HTML дашборда статистики слётов на React/Next.js с Tailwind CSS.

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
cd dashboard
npm install
```

### 2. Настройка (опционально)

Создайте файл `.env.local` для указания URL бэкенда:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

Если не указан, по умолчанию используется `http://localhost:8000`.

### 3. Запуск

```bash
# Терминал 1: Запустите FastAPI бэкенд
cd C:\Users\Administrator\Desktop\stats_bot_v2
python -m stats_bot.run_with_web "configs\bots.json"

# Терминал 2: Запустите Next.js
cd dashboard
npm run dev
```

Откройте [http://localhost:3000](http://localhost:3000) в браузере.

## 📁 Структура проекта

```
dashboard/
├── src/
│   ├── app/
│   │   ├── globals.css      # Все CSS стили
│   │   ├── layout.tsx       # Root layout
│   │   └── page.tsx         # Главная страница
│   ├── components/
│   │   ├── Sidebar.tsx      # Боковая навигация
│   │   ├── StatsTable.tsx   # Сводная таблица РУ/УЗБ/ВСЕГО
│   │   ├── GroupCard.tsx    # Карточка группы
│   │   ├── RoomsTable.tsx   # Таблица сравнения комнат
│   │   ├── WeeklyStats.tsx  # Недельная статистика
│   │   ├── PersonalStats.tsx# Личная статистика
│   │   ├── Recordings.tsx   # Записи работы
│   │   └── BotStats.tsx     # Статистика + настройки
│   ├── lib/
│   │   └── api.ts           # API клиент
│   └── types/
│       └── index.ts         # TypeScript типы
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── next.config.js
```

## 📋 Функционал

### Вкладки

1. **Дашборд** - Сводная таблица + карточки групп
2. **Статистика комнат** - Фильтры РУ/УЗБ/Все + таблица
3. **Группы** - Недельный рейтинг + все группы
4. **Личная статистика** - Карточки холодников
5. **Записи работы** - Почасовая сетка + видеоплеер
6. **Статистика** - Топ слётчиков + топ групп
7. **Настройки** - Статус бота + кеш

### Особенности

- ✅ Полная копия дизайна из HTML
- ✅ Навигация по датам
- ✅ Автообновление каждые 60 сек
- ✅ Локальное кеширование
- ✅ Адаптивный дизайн
- ✅ Тёмная тема
- ✅ Закупки ТГ в карточках групп
- ✅ "Осталось ТГ" в сводной таблице

## 🔌 API Эндпоинты

| Эндпоинт | Описание |
|----------|----------|
| `/api/dashboard` | Основные данные |
| `/api/weekly-stats` | Недельная статистика |
| `/api/personal-stats` | Личная статистика |
| `/api/recordings/team` | Записи команды |
| `/api/status` | Статус бота |
| `/api/cache-clear` | Очистка кеша |

## 🌐 Внешний доступ (ngrok)

```bash
# 1. ngrok для FastAPI
ngrok http 8000

# 2. Создайте .env.local
echo NEXT_PUBLIC_API_URL=https://xxxx.ngrok-free.app > .env.local

# 3. Перезапустите Next.js
npm run dev
```

## 🛠 Сборка

```bash
npm run build
npm start
```
